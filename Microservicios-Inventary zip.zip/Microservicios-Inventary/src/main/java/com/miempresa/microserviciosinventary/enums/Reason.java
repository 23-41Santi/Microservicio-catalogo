package com.miempresa.microserviciosinventary.enums;

public enum Reason {
    COUNT_ADJUSTMENT, DAMAGE, RETURN, OTHER
}
