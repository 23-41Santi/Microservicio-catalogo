package com.miempresa.microserviciosinventary.enums;

public enum ReservationStatus {
    RESERVED, RELEASED
}
